package com.springrest.springrest.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.dao.courseDao;
import com.springrest.springrest.entity.Course;
@Service
public class CourseServiceImpl implements CourseService {
	/*~~(Unable to determine parameter type)~~>*/@Autowired
	private courseDao courseDao;
	
	//List<Course>list;
	
	public CourseServiceImpl() {
		//list = new ArrayList<>();
		//list.add(new Course(145,"java","java basic"));
		//list.add(new Course(1434,"java","java basic"));
	}
	
	
	
	

	@Override
	public List<Course> getCourses() {
		// TODO Auto-generated method stub
		return courseDao.findAll();
	}





	@Override
	public Course getCourse(long courseId) {
		
		/*Course c = null;
		for(Course course:list) {
			if(course.getId()==courseId)
			{
				c=course;
				break;
			}
				
		}*/
		return courseDao.getReferenceById(courseId);
	}





	@Override
	public Course addCourse(Course course) {
		//list.add(course);
		courseDao.save(course);
		return course;
	}





	@Override
	public Course updateCourse(Course course) {
		// TODO Auto-generated method stub
		courseDao.save(course);
		return course;
	}





	@Override
	public void deleteCourses(long long1) {
		// TODO Auto-generated method stub
		 Course  entity = courseDao.getReferenceById(long1);
		courseDao.delete(entity);
	}

}
